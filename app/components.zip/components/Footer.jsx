export default function Footer() {
    return (
        <footer className="bg-[#031D34] text-white">
            <div className="mx-auto max-w-7xl px-4 py-14 sm:px-6 lg:px-8">
                <div className="grid gap-10 md:grid-cols-2 lg:grid-cols-4">
                    {/* Brand */}
                    <div>
                        <div className="flex items-center gap-3">
                            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-[#0F4C81]">
                                <span className="font-bold">BS</span>
                            </div>
                            <div>
                                <p className="font-bold">BHANSALI</p>
                                <p className="text-[9px] uppercase tracking-[0.2em] text-slate-400">
                                    Stainless Steel
                                </p>
                            </div>
                        </div>

                        <p className="mt-5 max-w-sm text-sm leading-6 text-slate-400">
                            Stainless steel flange solutions for industrial buyers across
                            Saudi Arabia, UAE, and the wider Middle East.
                        </p>
                    </div>

                    {/* Products */}
                    <div>
                        <h3 className="text-sm font-bold">Products</h3>

                        <ul className="mt-5 space-y-3 text-sm text-slate-400">
                            <li>
                                <a href="#products" className="hover:text-white">
                                    Weld Neck Flanges
                                </a>
                            </li>

                            <li>
                                <a href="#products" className="hover:text-white">
                                    Slip-On Flanges
                                </a>
                            </li>

                            <li>
                                <a href="#products" className="hover:text-white">
                                    Blind Flanges
                                </a>
                            </li>

                            <li>
                                <a href="#products" className="hover:text-white">
                                    Socket Weld Flanges
                                </a>
                            </li>
                        </ul>
                    </div>

                    {/* Information */}
                    <div>
                        <h3 className="text-sm font-bold">Information</h3>

                        <ul className="mt-5 space-y-3 text-sm text-slate-400">
                            <li>
                                <a href="#grades" className="hover:text-white">
                                    Material Grades
                                </a>
                            </li>

                            <li>
                                <a href="#specifications" className="hover:text-white">
                                    Specifications
                                </a>
                            </li>

                            <li>
                                <a href="#certifications" className="hover:text-white">
                                    Certifications
                                </a>
                            </li>

                            <li>
                                <a href="#contact" className="hover:text-white">
                                    Request a Quote
                                </a>
                            </li>
                        </ul>
                    </div>

                    {/* Contact */}
                    <div>
                        <h3 className="text-sm font-bold">Contact</h3>

                        <div className="mt-5 space-y-3 text-sm text-slate-400">
                            <a
                                href="tel:+919999999999"
                                className="block hover:text-white"
                            >
                                +91 99999 99999
                            </a>

                            <a
                                href="mailto:sales@example.com"
                                className="block hover:text-white"
                            >
                                sales@example.com
                            </a>

                            <p>
                                India · Exporting to Middle East
                            </p>
                        </div>
                    </div>
                </div>

                <div className="mt-12 border-t border-white/10 pt-6 text-center text-xs text-slate-500">
                    © {new Date().getFullYear()} Bhansali Stainless. All rights
                    reserved.
                </div>
            </div>
        </footer>
    );
}
